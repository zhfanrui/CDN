### Configuring Gogs
The other file allows you to export settings for Gogs. According to Gogs documentation, this is the preferred way.