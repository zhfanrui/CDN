# Install Gogs with ansible in GCP

## Introduction

This script is written to create a new Google Cloud instance named `dev`, and then configure this new instance automatically as a server to run `gogs`. The related softwares will be installed and configured well and users only need to register and use. 

## Machine setting

To run this script, we recommend you to create an instance of the following key features.

1. System image: **Debian 9**
2. Machine type: **2 vCPUs** and **512Mb RAM** is the baseline
3. In the area **Identity and API access**, tick **Allow full access to all Cloud APIs**.

There is a template for the management instance.

![](/img/template.jpg)

## Guide

1. Create a manager instance manually.

    You should log in your google account and go to the project management console. Click `Create instance` and choose an instance which we recommend you to do in the [Machine setting](#machine-setting). Click `Create` to create the instance.

2. Use **SSH** to connect to the instance created just now.

    You can use any tools. We believe that there is no difference between these tools but we only tested using the web one.

3. Download our package.

    You can use
    
    ```shell
    $ wget http://...
    ```

    to download the package. And then, you should run
    
    ```shell
    $ sudo apt-get install unzip && unzip *
    ```

    to unarchive the package.

4. Enter the certain directory.

    ```shell
    $ cd 2018_Group_10/Task\ two/
    ```

5. Run the script.

    ```shell
    $ bash run.sh [project_id] [password]
    ```

    where replace the square brackets to your own project_id in Google Cloud Platform and the password for your database.

6. Done :) You can access the web site by entering the ip address of new instance dev to the browser. (Make sure you are not using https link)


## Softwares and version installed

|**Name**|**Version**|
|---|:---:|
|ansible|2.6|
|gogs|0.11.53|
|postgreSQL|9.6.10 (default version in apt)|
|nginx|1.10.3 (default version in apt)|
|supervisor|3.3.1-1+deb9u1 (default version in apt)|
|git|2.11.0 (default version in apt)|

## Manage gogs

After the installation, gogs will be installed in `root/gogs` of the new instance and already started by supervisor. 

The setting file of gogs is in `/root/gogs/custom/conf/app.ini` and the log file of gogs is in `/home/gogs/gogs/log/gogs.log`.

The database user is **gogs** while the password is **the one that entered in the command above.**


If you got any question, please give us an [issue](https://github.com/dy1zan/2018_Group_10/issues)!
