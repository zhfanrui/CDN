# Group 10, 158.383
This is a private repository for our group. You can see two root folders: ["Task one"](https://github.com/dy1zan/2018_Group_10/tree/master/Task%20one) and ["Task two"](https://github.com/dy1zan/2018_Group_10/tree/master/Task%20two), corresponding to each tasks given in the assignment. Folder "img" stores the image for instructions.  

## Gogs

We have chosen the web platform, Gogs, which is a web platform similar to GitHub: for hosting and managing git repositories. Gogs allows a team of developers to collaborate and provides management tools such as bug reporting.

### Hardware requirements
According to Gogs' documentation, Gogs demands more as the team gets bigger, and as the amount of data grows. The recommended system requirements are,
`2 CPU cores and 512MB RAM` which is the baseline for teamwork.

Gogs will require HTTP traffic on port 80, and HTTPS (port 443) is optional.


### Software dependencies
Gogs has a number of dependencies,
* A database management system (MySQL, PostgreSQL).
* Git since Gogs is built on top of Git.
* Optional: Nginx for forwarding traffic to and from Gogs' server.
* Optional: Supervisor or systemd to register Gogs as a system service which automatically restarts, and starts on system boot.

We have chosen to include both the optional dependencies to set Gogs up for production use. The reason Nginx is somewhat important in production is to protect against spam or DoS attacks. Nginx allows for rate limiting, limiting how many requests or malicious requests that users may send. While we have not implemented rate limiting, this [link](https://www.nginx.com/blog/rate-limiting-nginx/) describe how it is done.
