# This SQL creates a new database, gogs, and a new user which has access to this database only.
CREATE DATABASE gogs;
GRANT ALL PRIVILEGES ON gogs.* TO 'gogs'@'localhost' IDENTIFIED BY 'rootpassword';
FLUSH PRIVILEGES;
