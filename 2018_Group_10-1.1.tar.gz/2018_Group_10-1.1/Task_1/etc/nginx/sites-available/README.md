### Nginx
A proxy which forwards HTTP traffic on port 80 to the Gogs port, 6000 is required.