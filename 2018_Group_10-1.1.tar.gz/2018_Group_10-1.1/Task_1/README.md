## Installing Gogs using a bash script
---
The bash script, [install.sh](install.sh), automates the installation of Gogs. It will install all dependencies outlined in [../README.md](../README.md).

### Using the bash script
To use the bash script, 
1.  you must have a **virtual machine** setup with Debian 9 (Strech) installed and it should allow HTTP traffic (port 80). It should have at least 512MB of available memory.

2.  you will need to download and make the script accessable via the virtual machine. This can be done by running the following command,
    ```bash
    wget https://raw.githubusercontent.com/dy1zan/2018_Group_10_Public/master/install.sh -O install.sh
    ```
    This will download install.sh into your current directory.

3.  you may then run the script using 
    ```bash
    sudo bash ./install.sh [password]
    ```
    where `[password]` will be the password of the PostgreSQL user, *gogs*.


### What does the bash script do?
* Installs the latest version of git.
* Installs the latest version of PostgreSQL, and creates a new user using the provided password.
* Installs the web platform: Gogs, and configures it.
* Installs the latest version of nginx, and configures it.
* Finally, Installs and configures the latest version of supervisor allowing Gogs to start on boot, and restart if it ever crashes.
