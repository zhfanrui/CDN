#!/bin/sh
cd /root/etherpad-lite
nohup /root/etherpad-lite/bin/run.sh --root &
sleep 31536000m
