
<div id="footer">
    <!-- <div class="line"></div> -->
    <footer><p>Powered By XXX<br>
Trade You © 2019</p></footer>
</div>