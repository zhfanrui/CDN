<?php
require_once 'checkUser.php';
checkUser();
require_once 'config/connect_db.php';
$uid = $_SESSION['USERID'];
$sql = "select user.*,product.*,product.id pid, orders.quantity as q from orders,product,user where product.userid=user.id and user.id={$uid} and product.id=orders.productid and orders.status=1;";
$res = $db->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/shopping-cart.css">
	<link rel="stylesheet" type="text/css" href="css/already_purchase.css">

</head>
<body>
	<div class="container">
    <div class="row">


   <?php foreach($res as $row):?>
    <div class="row">
        <div class="col-md-12">
            <div class = "goods goods-first">
                <!-- <input type = "checkbox" value="<?php echo $row['price']; ?>" /> -->
                <?php
                             $imgsql = "select * from album where pid=".$row['pid']." limit 1";
                             $images = $db->query($imgsql);
                             if($images){
                                 $img = $images->fetch_assoc();
                                 echo "<img src='uploads/".$img['image']."' >";
                             }
                             else{
                                 echo "<img src='' alt=''>";
                             }
                            ?>

                <dl class="dl-horizontal">
                    <dt>Price: </dt>
                    <dd><span class="price">$<?php echo $row['price']; ?></span></dd>
<!--                     <dt>Quantity: </dt>
                    <dd><?php echo $row['q']; ?></dd> -->
                    <dt>Location: </dt>
                    <dd><?php echo $row['address']; ?></dd>
                    <dt>Phone: </dt>
                    <dd><?php echo $row['phone']; ?></dd>
                </dl>

                <div class="button">
                   <button class="delete" type="button" onclick="detail(<?= $row['id'] ?>)">Detail</button>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach;?>

<!--
        <div class="col-md-12">
            <div class = "goods goods-first">

                <img src = "images/good1.jpg"/>
                <dl class="dl-horizontal">
                    <dt>价格：</dt>
                    <dd><span class="price">1299</span></dd>
                    <dt>所在地：</dt>
                    <dd>广州大学城</dd>
                    <dt>联系方式：</dt>
                    <dd>18813295242</dd>
                </dl>

                <div class="button">
                	<button class="delete" type="button">删除</button>
                    <!-- 下面的按钮是商品详情的链接 --
                </div>

            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class = "goods">

                <img src = "images\product-list\5.jpg"/>
                <dl class="dl-horizontal">
                    <dt>价格：</dt>
                    <dd><span class="price">199</span></dd>
                    <dt>所在地：</dt>
                    <dd>广州大学城</dd>
                    <dt>联系方式：</dt>
                    <dd>18813295242</dd>
                </dl>

                <div class="button">
                	<button class="delete" type="button">删除</button>
                	<!-- 下面的按钮是商品详情的链接 --
                    <a href="#"><button type="button">详情</button></a>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class = "goods goods-last">

                <img src = "images\product-list\1.jpg"/>
                <dl class="dl-horizontal">
                    <dt>价格：</dt>
                    <dd><span class="price">299</span></dd>
                    <dt>所在地：</dt>
                    <dd>广州大学城</dd>
                    <dt>联系方式：</dt>
                    <dd>18813295242</dd>
                </dl>

                <div class="button">
                	<button class="delete" type="button">删除</button>
                	<!-- 下面的按钮是商品详情的链接 --
                    <a href="#"><button type="button">详情</button></a>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12" class="pagination">
            <ul class="pagination">
                <li>
                    <a href="#">上一页</a>
                </li>
                <li>
                    <a href="#">1</a>
                </li>
                <li>
                    <a href="#">2</a>
                </li>
                <li>
                    <a href="#">3</a>
                </li>
                <li>
                    <a href="#">4</a>
                </li>
                <li>
                    <a href="#">5</a>
                </li>
                <li>
                    <a href="#">下一页</a>
                </li>
            </ul>
        </div> -->
    </div>

</div>
<script src="js/jquery-3.1.1.js"></script>
<script src="js/bootstrap.min.js"></script>
<script>

    function detail(id) {
        window.parent.location.href = "product_information.php?id=" + id;
    }

	$("button[class='delete']").bind('click',function(){
	   $(this).parent("div").parent('div').parent("div").parent('div').next('div').children('div').children('div').addClass('border');
       $(this).parent("div").parent('div').remove();
	})

</script>
</body>
</html>