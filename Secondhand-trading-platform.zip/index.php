<?php
require 'config/config.php';
require 'config/connect_db.php';
require_once 'lib/index.page.func.php';

$keywords=$_GET['keywords']?$_GET['keywords']:null;
$where=$keywords?"where product.name like '%{$keywords}%'":null;
$sql = "select * from product {$where} order by date desc ";
$res = $db->query($sql);
$totalRows = $res->num_rows;
$pageSize = 12;
$totalPage = ceil($totalRows/$pageSize);
$page=$_REQUEST['page']?(int)$_REQUEST['page']:1;
if($page<1||$page==null||!is_numeric($page))$page=1;
if($page>$totalPage)$page=$totalPage;
$offset=($page-1)*$pageSize;

$prosql = "select * from product {$where} order by date desc limit {$offset},{$pageSize}";
$prores = $db->query($prosql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Trade You</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/index_style.css" />
	<link rel="stylesheet" type="text/css" href="css/index_style_header.css" />
	<script type="text/javascript" src="js/jquery-3.1.1.js"></script>
	<script type="text/javascript" src="js/img_slider.js"></script>
</head>
<body>
	<?php include("top.php"); ?>
	<!-- <?php include("header.php"); ?> -->

	<!-- div id="content">
		<div class="banner">
			<div class="index_slider">
				<div id="img_roll">
				<a href="#">
						<img src="images/index-slider/1.jpg" alt="广告1">
						<img src="images/index-slider/2.jpg" alt="广告2">
						<img src="images/index-slider/3.jpeg" alt="广告3">
				</a>
				<div class="img_index_out">
           			 <div class="img_index">
              			 <span class="selected"></span>
               			 <span></span>
               			 <span></span>
           			 </div>
        		</div>
				</div>
			</div>
		</div> -->

		<div class="product_list">
			<div class="box_label">
				<h5>Products</h5>
			</div>
			<div class="line"></div>
			<div class="item-list">
				<ul class="items cleafix">
				<?php foreach ($prores as $row):?>
					<li class="item">
						<a href="product_information.php?id=<?php echo $row['id'];?>" class="product_img" target="_blank">
							<?php
					         $imgsql = "select * from album where pid=".$row['id']." limit 1";
					         $images = $db->query($imgsql);
					         if($images){
					             $img = $images->fetch_assoc();
					             echo "<img src='uploads/".$img['image']."' alt=''>";
					         }
					         else{
					             echo "<img src='' alt=''>";
					         }
					        ?>

						</a>
						<div class="info">
							<div class="price"><?php echo $row['price']; ?></div>
							<div class="name"><a href="product_information.php?id=<?php echo $row['id'];?>" ><?php echo $row['name']; ?></a></div>
							<div class="details">
								<a href="product_information.php?id=<?php echo $row['id'];?>" >More</a>
							</div>
							<div class="like">
								<a href="addToCart.php?id=<?php echo $row['id'];?>">Add to Cart</a>
							</div>
						</div>
					</li>
				<?php endforeach;?>
					<li class="item fixed"></li>
					<li class="item fixed"></li>
					<li class="item fixed"></li>
				</ul>
			</div>

			<div class="pager">
					<div class="pagerbar">
						<?php if($totalRows>$pageSize):
			                  echo showPage($page, $totalPage,"keywords={$keywords}");
                              endif;
                        ?>
					</div>
				</div>
		</div>
	</div>
	<?php include("footer.php"); ?>
	<script type="text/javascript">
	function search(){
		if(event.keyCode==13){
			var val=document.getElementById("search_goods").value;
			window.location="index.php?keywords="+val;
		}
	}
	</script>
</body>
</html>