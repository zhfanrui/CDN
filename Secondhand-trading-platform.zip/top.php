<!-- <div id="top">
    <div class="top_bar">
        <ul class="top_left">
            <?php if(isset($_SESSION['USERNAME'])==FALSE){?>
            <li><a href="login.php" class="login">Sign in</a></li>
            <li><a href="register.php" class="sign">Sign up</a></li>
            <?php }
                  else{
            ?>
            <li>Welcome, <?php echo $_SESSION['SNAME']; ?></li>
            <li><a href="logout.php" >Log out</a></li>
            <?php } ?>
        </ul>
        <ul class="top_right">
            <li><a href="#" class="favorite">Favorite</a></li>
            <li><a href="#" class="annoucement">Annoucement</a></li>
        </ul>
    </div>
</div> -->


<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand">Trade You</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">

        <?php if(isset($_SESSION['USERNAME'])==FALSE){?>
        <li class="nav-item">
          <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item"><a class="nav-link" href="login.php" class="login">Sign in</a></li>
        <li class="nav-item"><a class="nav-link" href="register.php" class="sign">Sign up</a></li>
        <?php }
              else{
        ?>

        <li class="nav-item">
          <span class="navbar-text">
            Welcome, <?php echo $_SESSION['SNAME']; ?>
          </span></li>

      <li class="nav-item">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
        <li class="nav-item"><a class="nav-link" href="personal_center.php?dash=1" class="personal">Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="personal_center.php" class="shopping">Shop Cart</a></li>
        <li class="nav-item"><a class="nav-link" href="logout.php" >Log out</a></li>
        <?php } ?>

    </ul>
<!--     <div class="search">
            <input type="text" id="search_goods" placeholder="Keywords" onkeypress="search()" value="<?php echo $keywords?>"/>
            <input type="button" id="search_btn" value="Search" onclick="search()">

    </div> -->

    <form class="form-inline my-2 my-lg-0" >
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" name="keywords">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit" onclick="search()">Search</button>
    </form>
  </div>

</nav>


<div class="container-fluid">
    <div class="row" id="head">
        <div class="col-md-2">
            <p><img class="img-circle" src="images/logo.png"></p>
        </div>
        <div class="col-md-10">
            <h4>Trade You</h4>
            <h4><small>University Students' Secondhand Trading Platform</small></h4>
        </div>
    </div >
    </div>