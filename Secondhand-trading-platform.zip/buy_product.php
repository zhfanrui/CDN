<?php
require_once 'checkUser.php';
checkUser();


if(isset($_GET['ids'])){
    // var_dump($_GET);
    foreach ($_GET['ids'] as $value) {
        // echo $value;
        echo buy($value);
    }
    return;
}

if(isset($_GET['id'])){
    if(is_numeric($_GET['id'])==FALSE){
        header("Location:".$config_basedir);
    }
    else{
        $validproduct=$_GET['id'];
        echo buy($validproduct);
        return;
    }
}
else{
    header("Location:".$config_basedir);
}



function buy($validproduct){
    $userid = $_SESSION['USERID'];
    require 'config/connect_db.php';
    $sql = "select * from product where id={$validproduct} and quantity>0;";
    $res = $db->query($sql);
    if($res->num_rows != 0){
        $newq = $res->fetch_array()['quantity'] - 1;
        $sql = "update product set quantity={$newq} where id={$validproduct};";
        $res = $db->query($sql);
    } else {
        return "Sold out!";
    }
    $sql = "select * from orders where productid={$validproduct} and userid={$userid};";
    $res = $db->query($sql);
    // echo $sql;
        // -1
    if ($res->num_rows == 0) {
        $sql = "insert into orders(productid,userid,quantity,date,status) values({$validproduct},{$userid},1,now(),1);";
    } else {
        $sql = "update orders set status=1 where productid={$validproduct} and userid={$userid};";
    }
    // echo $sql;
    $res = $db->query($sql);
    if($res){
        return "Succeed!";
        // header("Location:".$config_basedir."index.php");
    }
}