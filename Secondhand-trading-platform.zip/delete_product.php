<?php
require_once 'checkUser.php';
checkUser();
if(isset($_GET['id'])){
    if(is_numeric($_GET['id'])==FALSE){

        header("Location:".$config_basedir);
    }
    else{
        $validproduct=$_GET['id'];
    }
}
else{
    header("Location:".$config_basedir);
}
$userid = $_SESSION['USERID'];
require_once 'config/connect_db.php';
// $sql = "delete from product,album where product.userid={$userid} and product.id={$validproduct};";
$sql = "delete from album where pid={$validproduct};";
$res = $db->query($sql);
// echo $sql;
$sql = "delete from orders where productid={$validproduct};";
$res = $db->query($sql);
// echo $sql;
$sql = "delete from product where product.userid={$userid} and product.id={$validproduct};";
$res = $db->query($sql);
// echo $sql;
// echo $res;
if($res){
    header("Location:".$config_basedir."published.php");
}