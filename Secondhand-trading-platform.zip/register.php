<?php
require 'config/config.php';
require 'config/connect_db.php';
$defaults = array('username'=>'','sname'=>'','password'=>'','sure_password'=>'','phone'=>'','email'=>'');
if($_SERVER['REQUEST_METHOD']=='GET'){
    $errors = array();
    include 'show-form.php';
}else{
    $errors = validate_form($db);
    if(count($errors)){
        foreach ($_POST as $key=>$value){
            $defaults[$key] = $_POST[$key];
        }
         include 'show-form.php';
    }else{
            $pattern = '1234567890abcdefghijklmnopqrstuvwxyz
               ABCDEFGHIJKLOMNOPQRSTUVWXYZ';
            for($i=0;$i<16;$i++){
                $randomstring.=$pattern{(mt_rand(32,126))};
            }
            $verifyurl = "http://localhost/Secondhand-trading-platform/verify.php";
            $verifystring = urlencode($randomstring);
            $verifyemail = urlencode($_POST['email']);
            $validusername = $_POST['username'];

            $sql = "insert into user(username,sname,password,phone,email,verifystring,active,address) values('".$_POST['username']."','".$_POST['sname']."','".$_POST['password']."','".$_POST['phone']."','".$_POST['email']."','".addslashes($randomstring)."',1, '{$_POST['uni']}');";
            $db->query($sql);
            // echo $sql;
// $mail_body=<<<_mail_
// Hi, $validusername，
// 请点击下面的链接验证你的账号：
// $verifyurl?email=$verifyemail&verify=$verifystring
// _mail_;
//             mail($_POST['email'],"大学生二手交易平台用户验证", $mail_body);
//             echo "<h3>验证邮件已经发送到你所指定的邮箱地址，请点击验证邮件里的链接以验证你的账号。</h3><br/>";
//             echo "<h3><a href='".$config_basedir."'>返回首页</a></h3>";
            echo "Succeed!";
    header("Location:".$config_basedir);
    }

}
function validate_form($db){
    $error = array();

    if(!(isset($_POST['username'])&&(strlen($_POST['username'])>=6))){
        $error['username'] = "Username must be greater than 6 digits in length";
    }else{
        $checksql = "select * from user where username= '".$_POST['username']."';";
        $checkresult = $db->query($checksql);
        $checknumrows = $checkresult->num_rows;
        if($checknumrows==1){
            $error['username'] = "Username already exists";
        }
    }
    if($_POST['sname']==""||(strlen($_POST['sname'])==0)){
        $error['sname'] = "Nickname can not be blank";
    }

    if($_POST['password']==""||(strlen($_POST['password'])==0)){
        $error['password'] = "Password can not be blank";

    }else{
        if(preg_match("/[^0-9a-zA-Z]/", $_POST['password'])||(strlen($_POST['password'])<6)){
            $error['password'] = "Password can only contains letters and numbers and must be greater than 6 digits";
        }else{
            if($_POST['password']!=$_POST['sure_password']){
                $error['sure_password']= "Password should be the same";
            }
        }
    }
    if($_POST['phone']==""||(strlen($_POST['phone'])==0)){
        $error['phone'] = "Phone number can not be blank";
    }

    $email = filter_input(INPUT_POST,'email',FILTER_VALIDATE_EMAIL);
    if($email === false){
        $error['email']="Invalid email address";
    }

    if($_POST["uni"]==""||(strlen($_POST['uni'])==0)){
        $error['uni'] = "University name can not be blank";
    }
    return $error;
}