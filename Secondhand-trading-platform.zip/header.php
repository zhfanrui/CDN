<div id="header">
    <div class="logo_bgm">
        <img src="images/LOGO.png" alt="logo" />
    </div>
    <h3 class="logo_headline"><a href="index.php">Trade You</a></h2>
    <ul id="top_nav">
        <li><a href="index.php" class="index active">Home</a></li>
        <li><a href="#" class="classify">Category</a></li>
        <li><a href="#" class="publish">Publish</a></li>
    </ul>

</div>