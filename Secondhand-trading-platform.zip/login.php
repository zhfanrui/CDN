<?php
require 'config/config.php';
require 'config/connect_db.php';
if($_POST['submit']){
    $sql = "select * from user where username='".$_POST['username']."' and password='".$_POST['password']."';";
    $result = $db->query($sql);
    $numrows = $result->num_rows;
    if($numrows==1){
        $row = mysqli_fetch_assoc($result);
        if($row['active']==1){
            $_SESSION['USERNAME'] = $row['username'];
            $_SESSION['SNAME'] = $row['sname'];
            $_SESSION['USERID'] = $row['id'];
            header("Location:".$config_basedir);
        }
        else{
            echo "<h3>This account has not been verified yet. Please log in to your registered email address and click the verification link on this platform to complete the verification.<br/><a href='index.php'>Back to Home</a></h3>";

        }
    }
    else{
        header("Location:".$config_basedir."login.php?error=1");
    }

}
else{


?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Log in</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/index_style_header.css" />
    <link rel="stylesheet" href="css/landing.css">
</head>
<body>

    <?php include("top.php"); ?>


	<div class="content">

	<!-- <div class="left"></div> -->

	<div id="form">

        <h3>Log in</h3>

		<form action="<?php echo $_SERVER['SCRIPT_NAME'];?>" method="post" accept-charset="utf-8">
				Username: <input style="border: 1px solid #ccc"  type="text" id="username" class="username" name="username">
				<div class="tips"></div>

				Password: &nbsp;<input style="border: 1px solid #ccc"  type="password" id="password" class="password" name="password"><br/>
				<?php if($_GET['error']){
                    echo "&nbsp;&nbsp;&nbsp;The username or password is incorrect. Please re-enter.";
                }?>
				<div class="tips"></div>
                <input type="submit" id="button" name="submit" value="Log in" class="btn btn-outline-success my-2 my-sm-0">

				<div class="register">
					No account? <a href="register.php">Register</a>
				</div>
		</form>

	</div>

	<!-- <div class="right"></div> -->

    </div>

    <?php include("footer.php"); ?>
</body>
</html>
<?php
}
?>