<?php
require 'config/config.php';
if(isset($_GET['id'])){
    if(is_numeric($_GET['id'])==FALSE){

        header("Location:".$config_basedir);
    }
    else{
        $validproduct=$_GET['id'];
    }
}
else{
    header("Location:".$config_basedir);
}
require_once 'config/connect_db.php';
$prosql = "select product.id pid,product.*,user.* from product,user where user.id=product.userid and product.id={$validproduct};";
$prores = $db->query($prosql);
$prorow = $prores->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- <link href="css/bootstrap.min.css" rel="stylesheet"> -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/index_style_header.css" />
    <link rel="stylesheet" type="text/css" href="css/index_style_footer.css" />
     <link rel="stylesheet" type="text/css" href="css/product_information.css" />
    <title>商品详情</title>

    </script>

</head>
<body>
    <?php include("top.php"); ?>
    <div id="header">
        <div class="logo_bgm">
            <img src="images/LOGO.png" alt="logo" />
        </div>
        <h3 class="logo_headline"><a href="#">大学生二手交易平台</a></h2>
        <ul id="top_nav">
            <li><a href="index.php" class="index active">首页</a></li>
            <li><a href="#" class="classify">分类</a></li>
            <li><a href="#" class="publish">发布闲置</a></li>
        </ul>
    </div>
    <!--页头结束-->
    <div id="content">
        <div class="saler_information">
            <?php
					         $imgsql = "select * from album where pid=".$prorow['pid']." limit 1";
					         $images = $db->query($imgsql);
					         if($images){
					             $img = $images->fetch_assoc();
					             echo "<img src='uploads/".$img['image']."' alt='' class='img-responsive' width='304' height='236' >";
					         }
					         else{
					             echo "<img src='' alt='No Pic'>";
					         }
					        ?>

            <form action="#" class="form-group">
                <div class="show_saler">
                    <p><span class="glyphicon glyphicon-search"></span> Name: <span class="product_name"><?php echo $prorow['name']; ?></span></p>
                    <p><span class="glyphicon glyphicon-pushpin"></span> Price: <span class="product_price"><?php echo $prorow['price']; ?></span></p>
                    <p><span class="glyphicon glyphicon-user"></span> Up-loader: <span class="saler_name"><a href="#"><?php echo $prorow['sname']; ?><span class="glyphicon glyphicon-new-window"></span></a></span></p>
                    <p><span class="glyphicon glyphicon-map-marker"></span> Location: <span class="product_location"><?php echo $prorow['address']; ?></span></p>
                    <p><span class="glyphicon glyphicon-phone-alt"></span> Phone: <span class="product_phone">
                    <?php
                    if(isset($_SESSION['USERNAME'])){
                       echo $prorow['phone'];
                    }
                    else{
                       echo "<a href='login.php'>Log in to view contact details</a>";
                    }

                    ?>

                    </span></p>
                </div>
                <div class="choose-btn">
                    <button type="button" class="btn btn-success">Buy</button>
                    <button type="button" class="btn btn-primary" onclick="addToCart(<?php echo $prorow['pid']; ?>)"><span class="     glyphicon glyphicon-shopping-cart"></span> Add to Cart</button>
                    <!-- <button type="button" class="btn btn-primary"><span class="glyphicon glyphicon-star"></span> 关注</button> -->
                    <button type="button" class="btn btn-primary"><span class="glyphicon glyphicon-bullhorn"></span> Comment</button>
                </div>
            </form>
        </div>

        <div class="box_label">
                <h3>Description</h3>
        </div>
        <div class="product_main">
          <div class="main_row_one">
             <p class="saler_upload_main_one"><?php echo $prorow['description']; ?></p>
        </div>
        <div class="box_label">
                <h3>Pictures</h3>
        </div>
        <div class="main_row_two">
           <ul class="show_pic_list">
           <?php
					         $imgsql = "select * from album where pid=".$prorow['pid']." ";
					         $images = $db->query($imgsql);
					         if($images){
					             while($img = $images->fetch_assoc()){
					             echo "<li><a href='uploads/".$img['image']."' class='show_big' ><img src='uploads/".$img['image']."' alt='' class='img-responsive mainimg_one' width='304' height='236'></a></li>";
					             }
					         }
					        ?>


               <li></li>
               <li></li>
               <li></li>
           </ul>
        </div>


        </div>
    </div>
    <!--页脚-->
    <?php include("footer.php");?>
    <!--页脚结束-->
    <script>
    function addToCart(id){
    	window.location='addToCart.php?id='+id;
        }
    </script>
    <script type="text/javascript" src="js/jquery-3.1.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/show_big_pic.js"></script>
</body>
</html>