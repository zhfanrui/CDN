<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbdatabase = "tradePlatform";

$db = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbdatabase);