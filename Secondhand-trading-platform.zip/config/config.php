<?php
ini_set("error_reporting","E_ALL & ~E_NOTICE");
session_start();
$config_basedir = "http://localhost/Secondhand-trading-platform/";