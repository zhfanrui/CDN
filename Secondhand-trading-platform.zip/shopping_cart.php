<?php
require_once 'checkUser.php';
checkUser();
require_once 'config/connect_db.php';
$uid = $_SESSION['USERID'];
$sql = "select user.*,product.*,product.id pid, orders.quantity as q from orders,product,user where product.userid=user.id and user.id={$uid} and product.id=orders.productid and orders.status=0;";
$res = $db->query($sql);

?>

<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>购物车</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/shopping-cart.css" rel="stylesheet">
    <!-- 以下两个插件用于在IE8以及以下版本浏览器支持HTML5元素和媒体查询，如果不需要用可以移除 -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
</head>
<body>
<div class="container">

<form action="buy_product.php">
<div class="row">
        <div class="col-md-12">
            <!-- <form class="form-inline" role="form"> -->
                <!-- <div class="checkbox"> -->
                    <!-- <label>
                          <input type="checkbox" class="checked-all"><strong style="margin-left: 10px;font-size: 16px">Select All</strong>
                    </label> -->
                <!-- </div> -->
                <div class="col-md-2">
                    <label>Total $<span id="sum" style="color: red">0</span></label>
                    <button type="submit" class="btn btn-default">Pay now</button>
                </div>
            <!-- </form> -->
        </div>
    </div>


   <?php foreach($res as $row):?>
    <div class="row">
        <div class="col-md-12">
            <div class = "goods goods-first">
                <input type = "checkbox" name="ids[]" value="<?php echo $row['pid']; ?>" price="<?php echo $row['price']; ?>" />
                <?php
					         $imgsql = "select * from album where pid=".$row['pid']." limit 1";
					         $images = $db->query($imgsql);
					         if($images){
					             $img = $images->fetch_assoc();
					             echo "<img src='uploads/".$img['image']."' >";
					         }
					         else{
					             echo "<img src='' alt=''>";
					         }
					        ?>

                <dl class="dl-horizontal">
                    <dt>Price: </dt>
                    <dd><span class="price">$<?php echo $row['price']; ?></span></dd>
<!--                     <dt>Quantity: </dt>
                    <dd><?php echo $row['q']; ?></dd> -->
                    <dt>Location: </dt>
                    <dd><?php echo $row['address']; ?></dd>
                    <dt>Phone: </dt>
                    <dd><?php echo $row['phone']; ?></dd>
                </dl>
<!--                 <div class="button"> -->
<!--                 	<button class="delete" type="button">删除</button> -->

<!--                 </div> -->

            </div>
        </div>
    </div>
    <?php endforeach;?>
</form>
    <!-- <div class="row">
        <div class="col-md-12" class="pagination">
            <ul class="pagination">
                <li>
                    <a href="#">上一页</a>
                </li>
                <li>
                    <a href="#">1</a>
                </li>
                <li>
                    <a href="#">2</a>
                </li>
                <li>
                    <a href="#">3</a>
                </li>
                <li>
                    <a href="#">4</a>
                </li>
                <li>
                    <a href="#">5</a>
                </li>
                <li>
                    <a href="#">下一页</a>
                </li>
            </ul>
        </div>
    </div> -->

</div>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery-3.1.1.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="js/bootstrap.min.js"></script>
<script>
    $(function(){
        /*复选款点击事件*/
        /*根据复选框的状态改变其背景颜色*/
        /*选中商品为蓝色，不选为白色*/
        /*更新总选择商品的价钱*/
        $(".goods input:checkbox").click(function(){
            if($(this).is(':checked')){
                $(this).css("background-color","#307ac1");
                var oldSum = parseFloat($("#sum").text());
                var newSum = parseFloat($(this).attr('price')) + oldSum;
                $("#sum").text(newSum);
            }
            else{
                $(this).css("background-color","#fff");
                var oldSum = parseFloat($("#sum").text());
                var newSum = oldSum - parseFloat($(this).attr('price'));
                $("#sum").text(newSum);
            }
        });
        /*全选复选框点击事件*/
    })
</script>
</body>
</html>
